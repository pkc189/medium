export const CONTENT_SECTION_CLASSNAME = 'section-content';
export const MEMBERSHIP_PROMPT_CLASSNAME = 'postFade';

export const USER_ID_KEY = 'userId';
export const READ_COUNT_KEY = 'readCount';

export const FETCH_CONTENT_MESSAGE = 'fetchContent';
export const FETCH_USER_ID = 'fetchUserId';
