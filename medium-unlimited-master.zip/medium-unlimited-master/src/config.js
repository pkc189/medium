const config = {
  amplitude: {
    api_key: '<API-KEY>',
  },
};

export default config;
