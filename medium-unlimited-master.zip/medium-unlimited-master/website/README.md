# https://manojvivek.github.io/medium-unlimited/
Static site for [MediumUnlimited](https://github.com/manojVivek/medium-unlimited) live at [https://manojvivek.github.io/medium-unlimited/](https://manojvivek.github.io/medium-unlimited/) using the minimalist theme [Gravity](http://github.com/hemangsk/Gravity) for jekyll.

# Usage
Run the `start.sh` file in the root to bootstrap the local development environment.
